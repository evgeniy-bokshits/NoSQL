﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Driver;

namespace NoSQLMongodb
{
  class Program
  {
    static void Main(string[] args)
    {
      var client = new MongoClient("mongodb://localhost:27017");

      var database = client.GetDatabase("library");
      var collection = database.GetCollection<Book>("books");
      var exist = collection.AsQueryable().Any();

      var library = new Library();
      if (!exist)
      {
        database.DropCollection("books");
      }

      collection.InsertMany(library.Books);

      //#a
      var books = collection.AsQueryable().Where(b => b.Count > 1).ToList();

      Console.WriteLine("#a");
      foreach (var b in books)
      {
        Console.WriteLine(b.Name);
      }

      //#b
      books = collection.AsQueryable().Where(b => b.Count > 1).OrderBy(b => b.Name).ToList();

      Console.WriteLine("#b");
      foreach (var b in books)
      {
        Console.WriteLine(b);
      }

      //#c
      books = collection.AsQueryable().Where(b => b.Count > 1).Take(3).ToList();

      Console.WriteLine("#c");
      foreach (var b in books)
      {
        Console.WriteLine(b);
      }

      //#d
      books = collection.AsQueryable().Where(b => b.Count > 1).ToList();

      Console.WriteLine("#d");  
      Console.WriteLine(books.Count);

      //#3
      var book = collection.AsQueryable().OrderByDescending(b => b.Count).First();
     
      Console.WriteLine("#3");
      Console.WriteLine(book);

      //#4
      var authors = collection.AsQueryable().Select(b => b.Author).Distinct().ToList();

      Console.WriteLine("#4");
      foreach (var a in authors)
      {
        if (string.IsNullOrEmpty(a) == false)
          Console.WriteLine(a);
      }

      //#5
      books = collection.AsQueryable().Where(b => b.Author == null).ToList();

      Console.WriteLine("#5");
      foreach (var b in books)
      {
        Console.WriteLine(b);
      }

      //#6
      var updateDefinition = Builders<Book>.Update.Inc(b => b.Count, 1);
      collection.UpdateMany(Builders<Book>.Filter.Empty, updateDefinition);
      books = collection.AsQueryable().ToList();

      Console.WriteLine("#6");
      foreach (var b in books)
      {
        Console.WriteLine(b);
      }

      //#7
      //updateDefinition = Builders<Book>.Update.AddToSet(new StringFieldDefinition<Book>("Genre"), new string[] {"favorite"});
      //collection.UpdateMany(Builders<Book>.Filter.Empty, updateDefinition);
      //books = collection.AsQueryable().ToList();
      

      //Console.WriteLine("#6");
      //foreach (var b in books)
      //{
      //  Console.WriteLine(b);
      //}
    }
  }

  public static class Extensions
  {
    public static string ToStringGenres(this IEnumerable<string> source)
    {
      var stringBuilder = new StringBuilder();
      foreach (var s in source)
      {
        stringBuilder.Append(s);
      }

      return stringBuilder.ToString();
    }
  }

  public class Book
  {
    [BsonId]
    public ObjectId Id { get; set; }
    public string Name { get; set; }
    public string Author { get; set; }
    public int Count { get; set; }
    [BsonDateTimeOptions(DateOnly = true)]
    public DateTime YearOfPublication { get; set; }
    public string Genre { get; set; }

    public override string ToString()
    {
      return string.Format("{0,-25} - {1,-10} - {2,-10} - {3,-10} - {4,-10}", Name, Author, Count, Genre, YearOfPublication);
    }
  }

  public class Library
  {
    [BsonId]
    public string Id { get; set; }

    public string Name { get; set; }

    public Library()
    {
      Name = "Lol";
      Books = new List<Book>
      {
        new Book
        {
          Author = "Tolkien",
          Name = "Hobbit",
          Count = 5,
          Genre = "fantasy",
          YearOfPublication = new DateTime(2014, 1, 1)
        },
        new Book
        {
          Author = "Tolkien",
          Name = "Lord of the rings",
          Count = 3,
          Genre = "fantasy",
          YearOfPublication = new DateTime(2015, 1, 1)
        },
        new Book
        {
          Name = "Kolobok",
          Count = 10,
          Genre = "kids",
          YearOfPublication = new DateTime(2000, 1, 1)
        },
        new Book
        {
          Name = "Repka",
          Count = 11,
          Genre = "kids",
          YearOfPublication = new DateTime(2000, 1, 1)
        },
        new Book
        {
          Author = "Mihalkov",
          Name = "Dyadya Stiopa",
          Count = 5,
          Genre = "kids",
          YearOfPublication = new DateTime(2001, 1, 1)
        },
      };
    }
    public IList<Book> Books { get; set; }
  }
}
